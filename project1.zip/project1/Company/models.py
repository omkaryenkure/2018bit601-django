from django.db import models

class company(models.Model):
    c_name = models.CharField(max_length=30)
    owner_name = models.CharField(max_length=30)
    typeC = models.CharField(max_length=30)


    def __str__(self):
        return self.name

class user(models.Model):
    user=models.CharField(max_length=30)

class problem(models.Model):
    user = models.ForeignKey(user, on_delete=models.CASCADE)
    c_name = models.ForeignKey(company, on_delete=models.CASCADE)
    problem = models.CharField(max_length=100)
    duration = models.DurationField()
    image = models.ImageField()
    video = models.URLField(max_length=100)

class student(models.Model):
    user = models.ForeignKey(user, on_delete=models.CASCADE)
    s_name = models.CharField(max_length=30)
    branch = models.CharField(max_length=30)
    education = models.CharField(max_length=30)
    state = models.CharField(max_length=30)
    district = models.CharField(max_length=30)
    address = models.CharField(max_length=30)
    mobile_no=models.IntegerField()

class solution(models.Model):
    user = models.ForeignKey(user, on_delete=models.CASCADE)
    s_name = models.ForeignKey(student, on_delete=models.CASCADE)
    problem = models.CharField(max_length=100)
    duration = models.DateTimeField()


class solution_pro(models.Model):
    user = models.ForeignKey(user, on_delete=models.CASCADE)
    sol_name = models.ForeignKey(solution, on_delete=models.CASCADE)
    progress_detail = models.CharField(max_length=100)
    date = models.DateTimeField()
    image = models.ImageField()
    video = models.URLField(max_length=30)
    
