from django.contrib import admin



from .models import company,student,problem,solution,solution_pro,user
# admin.site.register(Company)
# admin.site.register(Owner)
class companyAdmin(admin.ModelAdmin):
    search_fields = ['c_name','owner_name', 'typeC']
    list_display = ['c_name','owner_name','typeC']
admin.site.register(company,companyAdmin)


class userAdmin(admin.ModelAdmin):
    search_fields = ['user']
    list_display = ['user']

admin.site.register(user,userAdmin)


class problemAdmin(admin.ModelAdmin):
    list_display  = ['c_name','problem','duration','image','video']

admin.site.register(problem,problemAdmin)

class studentAdmin(admin.ModelAdmin):


    list_display  = ['s_name','branch','education','state','district','address','mobile_no']

admin.site.register(student,studentAdmin)


class solutionAdmin(admin.ModelAdmin):


    list_display  = ['s_name','problem','duration']

admin.site.register(solution,solutionAdmin)


class solution_proAdmin(admin.ModelAdmin):


    list_display  = ['sol_name','progress_detail','date','image','video']

admin.site.register(solution_pro,solution_proAdmin)


